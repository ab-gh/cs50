// Prints a column of 3 bricks

#include <stdio.h>

int main(void)
{
    printf("#\n");
    printf("#\n");
    printf("#\n");
}
